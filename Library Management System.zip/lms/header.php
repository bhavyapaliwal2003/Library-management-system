            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
        </div>
    </div>
    <section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="admindashboard.php" class="menu-top-active">DASHBOARD</a></li>
                          
                            <li>
                                <a > Books </a>
                                <ul >
                                    <li><a href="admin\add-book.php">Add Book</a></li>
                                     <li ><a href="admin\manage-books.php">Manage Books</a></li>
                                </ul>
                            </li>
                           <li>
                                <a > Issue Books </a>
                                <ul>
                                    <li><a href="admin\issue-book.php">Issue New Book</a></li>
                                     <li><a  href="admin\manage-issued-books.php">Manage Issued Books</a></li>
                                </ul>
                            </li>
                             <li><a href="admin\membership-students.php">membership Students</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>