<?php
session_start();
error_reporting(0);
include('dbconnect.php');
if(strlen($_SESSION['login'])==0)
    {   
header('location:index.php');
}
else{ 
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System |  Issued Books</title>
</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Manage Issued Books</h4>
    </div>
    

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Issued Books 
                        </div>
                        <div class="panel-body">
                       

<?php $sql = "SELECT tblbooks.BookName,tblcategory.CategoryName,tblauthors.AuthorName,tblbooks.ISBNNumber,tblbooks.BookPrice,tblbooks.id as bookid,tblbooks.bookImage,tblbooks.isIssued from  tblbooks join tblcategory on tblcategory.id=tblbooks.CatId join tblauthors on tblauthors.id=tblbooks.AuthorId";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  
<div class="col-md-4" style="float:center; height:300px;">   


                                   
         <br>                                 <tr class="odd gradeX">
         <td class="center" width="300">
                                                <?php echo htmlentities($cnt);?></td> <br>
<td><img src="admin/bookimg/<?php echo htmlentities($result->bookImage);?>" width="100"></td> <br>
                                        
                                            <br /><b><?php echo htmlentities($result->BookName);?></b></td>
                                            <br>
                                            <td class="center"><?php echo htmlentities($result->CategoryName);?></td>
                                            <br>
                                            <td class="center"><?php echo htmlentities($result->AuthorName);?></td><br>
                                            <td class="center"><?php echo htmlentities($result->ISBNNumber);?></td><br>
                                            <td class="center"><?php echo htmlentities($result->BookPrice);?></td><br>
                                            <td class="center"><?php if($result->isIssued=='1'): ?></td><br>
                                            </tr>
                                                
<p style="color:red;">Book Not available</p>
<?php endif;?>
                            </div>

                                <?php $cnt=$cnt+1;}} ?>  
                      
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>


            
    </div>
    </div>
    </div>

  </body>
</html>
<?php } ?>
