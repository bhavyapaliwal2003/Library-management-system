            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
        </div>
    </div>
    <section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="admindashboard.php">DASHBOARD</a></li>
                           
                            <li>
                                <a > Books </a>
                                <ul >
                                    <li><a href="add-book.php">Add Book</a></li>
                                     <li ><a href="manage-books.php">Manage Books</a></li>
                                </ul>
                            </li>

                           <li>
                                <a > Issue Books </a>
                                <ul>
                                    <li><a href="issue-book.php">Issue New Book</a></li>
                                     <li><a  href="manage-issued-books.php">Manage Issued Books</a></li>
                                </ul>
                            </li>
                             <li><a href="membership-students.php">membership Students</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>