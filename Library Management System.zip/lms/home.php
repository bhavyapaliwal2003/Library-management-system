<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #body {
  background-color: #ffffff;
  font-family: Arial, sans-serif;
  font-size: 16px;
  color: #333;

}
#h1{
  font-size: 32px;
  font-weight: bold;
  margin-top: 0;

}
#button{
  font-size: 32px;
  font-weight: bold;
  margin-top: 0;

}

    </style>
</head>
<body>
    <h1 >library management system</h1>
    <h2>home</h2>
    <button type="submit" > <a href="loginadmin.php"> admin login</a></button>
    <button type="submit"> <a href="index.php"> user login</a></button>

</body>
</html>
